============
Installation
============

You can install mbpy using pip:

.. code-block:: console

    $ pip install mbpy
