=====
Usage
=====

To use mpip in a project:

.. click:: mbpy.cli:cli
   :prog: mpip
   :show-nested:

For more detailed information on each command, use the ``--help`` option:

.. code-block:: console

   $ mpip --help
   $ mpip <command> --help
